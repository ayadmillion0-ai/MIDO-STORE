package com.midostore.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private val yellow = Color.rgb(255,212,0)
    private val bg = Color.rgb(17,17,20)
    private val card = Color.rgb(27,27,30)
    private var game = ""
    private var selectedPack = ""
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun base(): LinearLayout {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(16,16,16,90)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
        return root
    }

    private fun tv(text:String, size:Float=18f, bold:Boolean=false): TextView =
        TextView(this).apply {
            this.text=text; textSize=size; setTextColor(Color.WHITE)
            if (bold) typeface=Typeface.DEFAULT_BOLD
            setPadding(8,10,8,10)
            gravity=Gravity.RIGHT
        }

    private fun button(text:String, action:()->Unit): Button =
        Button(this).apply {
            this.text=text; textSize=16f; setTextColor(Color.BLACK)
            setTypeface(null,Typeface.BOLD); setOnClickListener{action()}
            background=round(yellow,14)
        }

    private fun round(color:Int, radius:Int): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius=radius*resources.displayMetrics.density }

    private fun showHome() {
        base()
        root.addView(tv("👑  MIDO STORE",25f,true))
        val hero=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,18,18,18);background=round(Color.rgb(35,35,38),22)}
        hero.addView(tv("اشحن ألعابك بسهولة 🎮",25f,true))
        hero.addView(tv("اختر لعبتك وباقة الشحن المناسبة لك.",15f))
        hero.addView(button("ابدأ الشحن"){showGames()})
        root.addView(hero, LinearLayout.LayoutParams(-1,LinearLayout.LayoutParams.WRAP_CONTENT).apply{setMargins(0,12,0,12)})
        root.addView(tv("الألعاب",20f,true))
        val ff=button("FREE FIRE\nجواهر"){game="Free Fire";showPackages()}
        val ef=button("eFootball\nكوينز / نقاط"){game="eFootball";showPackages()}
        root.addView(ff); root.addView(ef)
        root.addView(tv("نسخة تجريبية: لا يتم تنفيذ أي عملية دفع حقيقية.",13f))
    }

    private fun showGames(){ base(); root.addView(tv("← اختر اللعبة",20f,true)); root.addView(button("FREE FIRE\nجواهر"){game="Free Fire";showPackages()}); root.addView(button("eFootball\nكوينز / نقاط"){game="eFootball";showPackages()}) }

    private fun showPackages() {
        base()
        root.addView(tv("← $game — اختر الباقة",20f,true))
        val packs=if(game=="Free Fire") arrayOf("50 جوهرة — 30 جنيه","100 جوهرة — 60 جنيه","520 جوهرة — 270 جنيه","2180 جوهرة — 1050 جنيه","5600 جوهرة — 2550 جنيه")
        else arrayOf("105 كوينز — السعر قريبًا","550 كوينز — السعر قريبًا","1280 كوينز — السعر قريبًا","Premium — السعر قريبًا")
        packs.forEach { p -> root.addView(button(p){selectedPack=p;showDetails()}) }
    }

    private fun showDetails(){
        base()
        root.addView(tv("← بيانات الشحن",20f,true))
        val id=EditText(this).apply{hint="أدخل Player ID";setTextColor(Color.WHITE);setHintTextColor(Color.GRAY);background=round(card,14);padding=16}
        root.addView(id)
        root.addView(tv("طريقة الدفع",19f,true))
        val rg=RadioGroup(this).apply{orientation=RadioGroup.VERTICAL}
        rg.addView(RadioButton(this).apply{text="فودافون كاش";setTextColor(Color.WHITE)})
        rg.addView(RadioButton(this).apply{text="بطاقة / محفظة";setTextColor(Color.WHITE)})
        root.addView(rg)
        root.addView(button("تأكيد الطلب"){if(id.text.toString().trim().isEmpty()) Toast.makeText(this,"اكتب Player ID أولاً",Toast.LENGTH_SHORT).show() else showSuccess()})
    }

    private fun showSuccess(){
        base(); root.gravity=Gravity.CENTER
        root.addView(tv("✓",64f,true)); root.addView(tv("تم إرسال الطلب",26f,true)); root.addView(tv("تم تسجيل طلبك في النسخة التجريبية بنجاح.",15f))
        root.addView(button("العودة للرئيسية"){showHome()})
    }
}
