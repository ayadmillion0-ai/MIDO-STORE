# MIDO STORE Android

مشروع Android Studio أولي لتطبيق شحن ألعاب.

## التشغيل
1. افتح المجلد في Android Studio.
2. انتظر Gradle Sync.
3. اختر `app`.
4. Build > Build APK(s).

هذه نسخة تجريبية فقط؛ لا يوجد دفع أو شحن حقيقي متصل بخدمات خارجية.
